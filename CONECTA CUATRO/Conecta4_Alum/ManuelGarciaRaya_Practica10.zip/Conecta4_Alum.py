import numpy as np 
from dataclasses import dataclass 
from copy import deepcopy 


@dataclass
class Nodo:
    tablero: np.array
    vAlturas: np.array
    ultima_ficha = None
    fila: int
    col: int
    

    def __init__(self, tablero):
        self.tablero = tablero
        self.vAlturas = np.array([5, 5, 5, 5, 5, 5, 5])
        self.ultima_ficha = None
        self.col = None

    def __str__(self):
        visual = {-1: "🟡", 1: "🔴", 0.0: " "}
        string = ""
        for i in range(self.tablero.shape[0]):
            for j in range(self.tablero.shape[1]):
                if i==0 and j==0:
                    string+="|"
                if self.tablero[i, j] == 0:
                    string += "    |"
                else:
                    string += f" {visual[self.tablero[i, j]]} |"
            if  i < self.tablero.shape[0]-1:
                string += f"\n ----+----+----+----+----+----+----\n|"
            else:
                
                string += f"\n ----+----+----+----+----+----+----\n"
        return f"{string}"

def NodoInicial():
    tablero = np.zeros((6,7))
    return Nodo(tablero)

def NodoInicial_Poda():
    tablero = np.array([
        [1, 0, 0, 0, 0, 0, 0],
        [-1, 0, 0, 0, 0, 0, 1],
        [1, 1, -1, 0, -1, -1, 1],
        [-1, 1, -1, -1, 1, 1, -1],
        [-1, -1, 1, 1, -1, 1, 1],
        [1, -1, -1, -1, 1, 1, -1]
    ])
    return Nodo(tablero)


def aplicaJugada(actual: Nodo, jugador: int) -> Nodo:
    nuevo = deepcopy(actual)
    nuevo.tablero[nuevo.vAlturas[nuevo.col], nuevo.col] = jugador
    nuevo.ultima_ficha = [nuevo.vAlturas[nuevo.col], nuevo.col]
    nuevo.vAlturas[nuevo.col] -= 1
    return nuevo

def esValida(actual: Nodo) -> bool:
    if actual.col == None:
        return False
    elif actual.vAlturas[actual.col] >= 0:
        return True
    else:
        return False

def terminal(actual: Nodo) -> bool:
    if np.count_nonzero(actual.tablero) == 42:
        return True
    elif utilidad(actual) != 0:
        return True
    else:
        return False

def utilidad(nodo: Nodo) -> int:
    copia = deepcopy(nodo)
    jugador = copia.tablero[copia.ultima_ficha[0], copia.ultima_ficha[1]]
    x = copia.ultima_ficha[0]
    y = copia.ultima_ficha[1]
    
    # Comprobamos si hay 4 en raya en horizontal
    contador = 0
    for i in range (7):
        if copia.tablero[x, i] == jugador:
            contador += 1
            if contador == 4:
                return jugador*100
        else:
            contador = 0
    
    # Comprobamos si hay 4 en raya en vertical
    contador = 0
    for i in range (6):
        if copia.tablero[i, y] == jugador:
            contador += 1
            if contador == 4:
                return jugador*100
        else:
            contador = 0
                
    # Comprobamos si hay 4 en raya en diagonal
    # contador = 0
    # if

def heuristica(nodo: Nodo) -> int:
    raise NotImplementedError
