import numpy as np 
from dataclasses import dataclass 
from copy import deepcopy 


@dataclass
class Nodo:
    tablero: np.array
    # Puede añadir más atributos si lo considera oportuno 

    def __init__(self, tablero):
        self.tablero = tablero

    def __str__(self):
        visual = {-1: "🟡", 1: "🔴", 0.0: " "}
        string = ""
        for i in range(self.tablero.shape[0]):
            for j in range(self.tablero.shape[1]):
                if i==0 and j==0:
                    string+="|"
                if self.tablero[i, j] == 0:
                    string += "    |"
                else:
                    string += f" {visual[self.tablero[i, j]]} |"
            if  i < self.tablero.shape[0]-1:
                string += f"\n ----+----+----+----+----+----+----\n|"
            else:
                
                string += f"\n ----+----+----+----+----+----+----\n"
        return f"{string}"

@dataclass
class Jugada:
    # Implementar de acuerdo con lo que necesite o bien, puede eliminarlo y realizar 
    # los cambios en el resto del código que hace referencia a Jugada.
    pass 

def NodoInicial():
    tablero = np.zeros((6,7))
    return Nodo(tablero)

def NodoInicial_Poda():
    tablero = np.array([
        [1, 0, 0, 0, 0, 0, 0],
        [-1, 0, 0, 0, 0, 0, 1],
        [1, 1, -1, 0, -1, -1, 1],
        [-1, 1, -1, -1, 1, 1, -1],
        [-1, -1, 1, 1, -1, 1, 1],
        [1, -1, -1, -1, 1, 1, -1]
    ])
    return Nodo(tablero)


def aplicaJugada(actual: Nodo, jugada: Jugada, jugador: int) -> Nodo:
    raise NotImplementedError


def esValida(actual: Nodo, jugada: Jugada) -> bool:
    raise NotImplementedError


def terminal(actual: Nodo) -> bool:
    raise NotImplementedError


def utilidad(nodo: Nodo) -> int:
    raise NotImplementedError

def heuristica(nodo: Nodo) -> int:
    raise NotImplementedError
